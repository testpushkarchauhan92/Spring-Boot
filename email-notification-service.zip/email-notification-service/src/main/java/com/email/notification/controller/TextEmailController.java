package com.email.notification.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.email.notification.model.EmailTemplate;
import com.email.notification.service.EmailService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/v1/notification")
@Slf4j
public class TextEmailController {

	private final static Logger log = Logger.getLogger(TextEmailController.class.getName());

	@Autowired
	private EmailService emailService;

	@PostMapping(value = "/textemail", consumes = "application/json", produces = "application/json")
	public String sendEmail(@RequestBody EmailTemplate emailTemplate) {
		try {
			log.info("Sending Simple Text Email....");
			emailService.sendTextEmail(emailTemplate);
			return "Email Sent!";
		} catch (Exception ex) {
			return "Error in sending email: " + ex;
		}
	}

	/*
	@PostMapping(value = "/attachemail", consumes = "multipart/form-data")
	public String sendEmailWithAttachment(@RequestPart(value = "file") MultipartFile file) {
		try {
			log.info("Sending Attachment Email....");
			// emailService.sendEmailWithAttachment(file);
			emailHelper.sendEmail();
			return "Email Sent!";
		} catch (Exception ex) {
			return "Error in sending email: " + ex;
		}
	}
	*/
	
	@PostMapping(value = "/attachemail")
	public String sendEmailWithAttachment() {
		try {
			log.info("Sending Attachment Email....");
			emailService.sendEmail();
			return "Email Sent!";
		} catch (Exception ex) {
			return "Error in sending email: " + ex;
		}
	}

}
