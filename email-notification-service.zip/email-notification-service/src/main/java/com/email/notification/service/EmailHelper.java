//package com.email.notification.service;
//
//import java.util.Date;
//import java.util.Properties;
//
//import javax.mail.Message;
//import javax.mail.Multipart;
//import javax.mail.PasswordAuthentication;
//import javax.mail.Session;
//import javax.mail.Transport;
//import javax.mail.internet.InternetAddress;
//import javax.mail.internet.MimeBodyPart;
//import javax.mail.internet.MimeMessage;
//import javax.mail.internet.MimeMultipart;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//@Component
//public class EmailHelper {
//
//	@Value("${email.address}")
//	private String attchEmailAddr;
//	@Value("${spring.mail.host}")
//	private String host;
//	@Value("${spring.mail.port}")
//	private String port;
//	@Value("${spring.mail.username}")
//	private String email_username;
//	@Value("${spring.mail.password}")
//	private String email_password;
//	@Value("${email_subject}")
//	private String email_subject;
//	@Value("${email_filePath}")
//	private String email_filePath;
//	@Value("${email_body}")
//	private String email_body;
//	@Value("${email_type}")
//	private String email_type;
//
//	public void sendEmail() {
//		try {
//			Properties props = new Properties();
//			props.put("mail.smtp.auth", "true");
//			props.put("mail.smtp.starttls.enable", "true");
//			props.put("mail.smtp.host", "smtp.gmail.com");
//			props.put("mail.smtp.port", "587");
//
//			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
//				protected PasswordAuthentication getPasswordAuthentication() {
//					return new PasswordAuthentication(email_username, email_password);
//				}
//			});
//			Message msg = new MimeMessage(session);
//			msg.setFrom(new InternetAddress(email_username, false));
//
//			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email_username));
//			msg.setSubject(email_subject);
//			msg.setSentDate(new Date());
//
//			MimeBodyPart messageBodyPart = new MimeBodyPart();
//			messageBodyPart.setContent(email_body, email_type);
//
//			Multipart multipart = new MimeMultipart();
//			multipart.addBodyPart(messageBodyPart);
//
//			MimeBodyPart attachPart = new MimeBodyPart();
//			attachPart.attachFile(email_filePath);
//			multipart.addBodyPart(attachPart);
//			msg.setContent(multipart);
//			Transport.send(msg);
//		} catch (Exception exe) {
//			exe.printStackTrace();
//		}
//	}
//}